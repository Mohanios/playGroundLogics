
import Foundation

// [Mark: Palindrome Condition]

func palindrome(num:Int){
var n = num
var rev = 0
    
while (n > 0)
{
    let dig = n % 10
    rev = rev * 10 + dig
    n = n / 10
}
    if (num == rev){
        print("\(num ) is Palindrome")
    }else{
        print("\(num ) is not Palindrome")
    }
}

palindrome(num:565)
