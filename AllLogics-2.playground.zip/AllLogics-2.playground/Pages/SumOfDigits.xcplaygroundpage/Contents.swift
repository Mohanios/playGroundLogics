
import Foundation

// [Mark: SumOfDigits Condition]

func SumOfDigits(num:Int){
var n = num
var rev = 0
    
while (n > 0)
{
    let dig = n % 10
    rev = rev + dig
    n = n / 10
}
   
print("Sum of digits \(num) is \(rev )")

}

SumOfDigits(num:345)

