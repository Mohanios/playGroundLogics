
import Foundation

// [Mark: Prime Number Condition]

func primeNum(num:Int){
    var prime: Int = 1
    var i = 2
    while (i < num){
        if (num % i == 0){
            prime = 0
            i += 1
        }
        i += 1
    }
    if (prime == 1){
        print("\(num) is prime")
    }else{
        print("\(num) is not prime")
    }
}

primeNum(num: 8)
