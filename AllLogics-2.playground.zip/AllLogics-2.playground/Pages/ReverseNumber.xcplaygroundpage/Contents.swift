
import Foundation

// [Mark: Reverse Number]

func reverseNum(num:Int){
var n = num
var rev = 0
    
while (n > 0)
{
    let dig = n % 10
    rev = rev * 10 + dig
    n = n / 10
}
   print("The Reverse of \(num) is \(rev)")
}

reverseNum(num: 12)
