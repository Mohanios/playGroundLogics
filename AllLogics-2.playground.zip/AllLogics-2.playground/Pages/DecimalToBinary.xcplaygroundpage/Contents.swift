
import Foundation

// [Mark: ConvertToBinary]

func convertToBinary(decimal: Int)->String{
    if decimal == 0 {
        print("0")
        return "0"
    }
    var n = 0, c = 0, k:[String] = [], fs = ""
    n = decimal
    while n > 0 {
        c = n % 2
        n = n/2
        k.append("\(c)")
    }
    for i in k.reversed() {
        fs += "\(i)"
    }
    print(fs)
    return fs
}

convertToBinary(decimal: 0)
