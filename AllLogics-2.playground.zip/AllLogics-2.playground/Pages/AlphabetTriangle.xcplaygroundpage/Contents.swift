
import Foundation

// [Mark: alphabetTraingle]

func alphabetTraingle(value: String) {
  for i in 1...value.count {
    let index = String(value.prefix(i))
     print(index)
  }
}

alphabetTraingle(value: "ABCDEFG")
