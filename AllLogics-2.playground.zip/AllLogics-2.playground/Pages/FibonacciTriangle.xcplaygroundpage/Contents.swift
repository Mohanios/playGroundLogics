
import Foundation

// [Mark: FibonacciTriangle]

func FibonacciTriangle(n:Int)->Int{
    if n == 0{
        return n
    }
    else if n == 1 {
        print("1")
        return n
    }
    print("\(1) \n")
    for i in 1...n-1 {
        var a = 0
        var b = 1
        print("\(b)",terminator: " ")
        for _ in 1...i {
            let c = a + b
            print("\(c)",terminator: " ")
            a = b
            b = c
        }
        print("\n")
    }
    return n
}

FibonacciTriangle(n: 0)
