
import Foundation

// [Mark: Swap two numbers without using third variable ]

func swapTwoNumbers(n1:Int,n2:Int)->String{
    var x = n1
    var y = n2
    if (x == 0) && (y == 0) {
        return ("n1=\(x), n2=\(y)")
    }
    else if (x == 0) && (y != 0) {
        return ("n1=\(n2), n2=\(n1)")
    }
    else if (x != 0) && (y == 0) {
        return ("n1=\(n2), n2=\(n1)")
    }
    x = x*y
    y = x/y
    x = x/y
    return("n1=\(x), n2=\(y)")
}

print(swapTwoNumbers(n1: 4, n2: 0 ))
