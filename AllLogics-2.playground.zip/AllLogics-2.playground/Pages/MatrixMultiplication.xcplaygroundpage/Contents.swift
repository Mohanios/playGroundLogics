
import Foundation

// [Mark: MatrixMultiplication]

func matrixMultiply(matrixA:[[Int]],matrixB:[[Int]])->[[Int]]{
    if matrixA.count != matrixB.count{
        print("Illegal matrix dimension")
        return[[]]
    }
    let size = matrixA.count
    var result:[[Int]] = [[Int]](repeating:[Int](repeating: 0, count: size),count:size)
    for i in 0..<result.count{
        for j in 0..<matrixA.count{
            for k in 0..<matrixB.count{
                result[i][j] += matrixA[i][k] * matrixB[k][j]
            }
        }
    }
    print(result)
    return result
}

matrixMultiply(matrixA: [[2,3],
                        [4,5]]
            , matrixB: [[4,5],
                        [5,6],])



