
import Foundation

// [Mark: NumberToCharacters]

func NumberToCharacters(num:Int){
var n = num
var rev = 0
    var arr : [String] = []
    
while (n > 0)
{
    let dig = n % 10
    rev = rev * 10 + dig
    n = n / 10
}
    n = rev
    while n > 0
    {
       let r = n % 10
        switch r {
        case 1:
            print("One ",terminator : "" )
        case 2:
        print("Two ",terminator : "")
        case 3:
         
        print("Three ",terminator : "")
        case 4:
        print("Four ",terminator : "")
        case 5:
        
        print("Five ",terminator : "")
        case 6:
        
        print("Six ",terminator : "")
        case 7:
        
        print("Seven ",terminator : "")
        case 8:
        
        print("Eight ",terminator : "")
        case 9:
       
        print("Nine ",terminator : "")
        case 0:
         //   arr.append("Zero")
        print("Zero ",terminator : "")
        break
        default:
            print("ttt")
        }
        n = n/10
    }
}

NumberToCharacters(num:87456 )



