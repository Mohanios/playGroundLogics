
import UIKit

// [Mark: Fibonacci serious]

func fibbonaci(num:Int) -> [Int]{
    
    // Initialising the first two terms
    var sequence = [0, 1]
    if num <= 1 {
        return sequence
    }
// Looping for calculating sum of previous two terms in sequence
    for _ in 0...num - 3 {
        let n1 = sequence.count - 2
        let first = sequence[n1]
        let second = sequence.last!
        sequence.append(first + second)
    }
    print(sequence)
    return sequence
    
}

fibbonaci(num: 5)

