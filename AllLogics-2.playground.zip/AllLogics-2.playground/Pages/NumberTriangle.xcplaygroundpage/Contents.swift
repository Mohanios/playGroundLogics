
import Foundation

// [Mark: numberTriangle]

func numberTriangle(no1:Int){
    var no = 1
    for i in 1...no1 {
        for _ in 1...no1+1 - i {
            print(" ", terminator: " ")
        }
        for j in 1...i {
            print("\(j)", terminator: " ")
            no = j
        }
        for _ in 1..<no {
            no -= 1
            print("\(no)", terminator: " ")
        }
        print("")
    }
}
numberTriangle(no1: 5)

func numbersInTriangle(n:Int){
   var j: Int = 0
    var pattern = String()
       for i in 1...n {
           for _ in 1...n+1 - i {
               pattern += " "
           }
           for j in 1...i {
              // pattern += "\(j)"
           }

           j = i - 1
           while j >= 1 {
               pattern += "\(j)"
               j -= 1
           }
            pattern += "\n"
       }
       print(pattern)
}

numbersInTriangle(n: 7)

