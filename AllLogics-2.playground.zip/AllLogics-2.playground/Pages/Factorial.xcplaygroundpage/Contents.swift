
import Foundation

// [Mark: Factorial Condition]

func factorial(num:Int)->Int {
    if num == 0{
        return num
    }
    var fact = 1
    for i in 1...num{
        fact = fact * i
    }
    print(fact)
    return fact
}

factorial(num: 4)
