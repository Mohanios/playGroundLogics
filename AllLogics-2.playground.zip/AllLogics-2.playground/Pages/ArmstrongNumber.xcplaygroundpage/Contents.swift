
import Foundation

// [Mark: Armstrong Number]

func ArmstrongNumber(num:Int){
var n = num
var rev = 0
    
while (n > 0)
{
    let dig = n % 10
    rev = rev + (dig*dig*dig)
    n = n / 10
}
    if (num == rev){
        print("\(num ) is Armstrong Number")
    }else{
        print("\(num ) is not Armstrong Number")
    }
}

ArmstrongNumber(num:371)

